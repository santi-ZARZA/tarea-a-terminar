﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {

           
            Ingrediente i1 = new Ingrediente("Azucar", 3);
            Ingrediente i2 = new Ingrediente("Harina", 10);
            Ingrediente i3 = new Ingrediente("Leche", 50);
            Ingrediente[]  lista1= new Ingrediente[3];
            lista1[0] = i1;
            lista1[1] = i2;
            lista1[2] = i3;
            Ingrediente[] lista2 = new Ingrediente[4];
            lista2[0] = i1;
            lista2[1] = i2;
            lista2[2] = i3;
            lista2[3] = new Ingrediente("Ralladura de limon", 5);


            List<Galletita> paqueteDeGalletitas = new List<Galletita>();  //ArrayList* lista = al_NewArrayList

            Galletita g1; // Galletita* g1 = NULL;
            g1 = new Galletita("Naranja", true, 50, false, lista1);
    
            Galletita g2; // Galletita* g1 = NULL;
            g2 = new Galletita("Limon", false, (float)3.25, true, lista2); //g1= (Galletita*) malloc(sizeof(Galletita)); o g1 = newGalletita();


            paqueteDeGalletitas.Add(g1);
            paqueteDeGalletitas.Add(g2);

           /* Galletita aux;
            for (int i = 0; i < paqueteDeGalletitas.Count; i++)
            {
                aux = paqueteDeGalletitas.ElementAt(i);

                aux.mostrar();

            }*/

            foreach (Galletita aux in paqueteDeGalletitas)
            {
                aux.mostrar();
            }

                Console.Read();

        }

      
    }
}


/*int edad;
           String nombre;
           

           Console.WriteLine("Ingrese su nombre: ");
           nombre = Console.ReadLine();

           Console.WriteLine("Ingrese su edad: ");
           edad =int.Parse(Console.ReadLine());

           Console.WriteLine("Su nombre es: {0} y tiene {1} años", nombre, edad);
           Console.Read(); */