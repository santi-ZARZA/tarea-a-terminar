﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Galletita
    {
        String sabor;
        bool tieneChispas;
        float peso;
        bool aptaCeliacos;
        Ingrediente[] ingredientes;


        public Galletita()
        {
        }

        public Galletita(String sabor, bool tieneChispas, float peso, bool aptaCeliacos, Ingrediente[] ing)
        {
            this.ingredientes = ing;
            this.sabor = sabor;
            this.tieneChispas = tieneChispas;
            this.peso = peso;
            this.aptaCeliacos = aptaCeliacos;
        }


        public void mostrar()
        {
            Console.WriteLine("{0}--{1}--{2}--{3}", this.aptaCeliacos, this.peso, this.sabor, this.tieneChispas);
            Console.WriteLine("Ingredientes: ");

            for (int i = 0; i < this.ingredientes.Length; i++)
            {
                this.ingredientes[i].mostrar();
            }



        }

    }
}
