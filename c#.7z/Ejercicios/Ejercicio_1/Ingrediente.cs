﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Ingrediente
    {
        string descripcion;
        int cantidad;

        public Ingrediente(string descripcion, int cant)
        {
            this.descripcion = descripcion;
            this.cantidad = cant;
        }

        public void mostrar()
        {
            Console.WriteLine("Descripcion: {0} -- Cantidad: {1}", this.descripcion, this.cantidad);
        }

    }
}
